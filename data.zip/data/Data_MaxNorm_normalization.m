% In this script,
% %--------------
% we will find the max norm among all data samples, then
% we'll normalize using this value so that we have the norm of any sample,
% which serves as the norm of the loss function derivative, leq to that max
% norm value.


c1 = 0.5;


% Define the input and output Excel file names
% inputFileName = 'XY_train_zscore_Normalized.csv'; 
% outputFileName = 'XY_train_zscore_MaxNormalized (c1=0.5).csv';
inputFileName = 'XY_train_MinMax_Normalized.csv'; 
outputFileName = 'XY_train_MinMax_MaxNormalized (c1=0.5).csv';

% Read the data from the Excel file
data = csvread(inputFileName,1,0);

% find the max norm across all data samples
%------------------------------------------
MaxNorm = norm( zeros(1,size(data,2)) );
for i = 1:size(data,1)
    if norm( data(i,:) ) > MaxNorm
        MaxNorm = norm( data(i,:) );
        Index = i; % index of the sample with MaxNorm
    end
end

% Normalize each row by the MaxNorm 
%-----------------------------------
normalizedData = zeros(size(data)); % Preallocate for normalized data
for i = 1:size(data, 1)
    normalizedData(i, :) = c1 * data(i, :) / MaxNorm; % Normalize each data sample by MaxNorm
end

% Save the norm of all data samples to double-check on them
%----------------------------------------------------------
DataNorm = zeros(size(data,1),1);
for i = 1:size(data, 1)
    DataNorm(i) = norm(normalizedData(i, :));
end



% Write the normalized data to a new Excel file
csvwrite(outputFileName, normalizedData);

% disp('Normalization complete. Output saved to ''x_train_zscore_MaxNormalized.csv''');
disp('Normalization complete. Output saved to ''x_train_MinMax_MaxNormalized.csv''');

