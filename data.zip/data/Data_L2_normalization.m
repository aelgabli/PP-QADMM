% This script, from Chat GPT, to perform L2 normalization to each row of the
% dataset, i.e., the L2 norm of each row will be forced to be leq ONE.

% This is done by dividing each row by its L2-norm value.

% Define the input and output Excel file names
inputFileName = 'x_train_nonNormalized.csv'; % Change this to your input file
outputFileName = 'x_train_L2_normalized.csv'; % Output file name

% Read the data from the Excel file
data = csvread(inputFileName,1,0);


% Normalize each row
normalizedData = zeros(size(data)); % Preallocate for normalized data
% normalizedData(1,:) = data(1,:);
for i = 1:size(data, 1)
    row = data(i, :);
    rowNorm = norm(row, 2); % Calculate the L2 norm of the row
    if rowNorm > 0
        normalizedData(i, :) = row / rowNorm; % Normalize the row
    else
        normalizedData(i, :) = row; % Keep the row as is if it's all zeros
    end
end

% Write the normalized data to a new Excel file
csvwrite(outputFileName, normalizedData);

disp('Normalization complete. Output saved to normalized_output.csv.');
